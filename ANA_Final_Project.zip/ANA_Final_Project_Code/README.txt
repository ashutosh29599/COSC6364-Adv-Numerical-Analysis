Project Topic :
Non Uniform Fast Fourier Transform
Theme: implement and study FFT algorithms for non-uniform distribution of sampled points


How to run the code:-------------------------------------------------------------------------------------------------

on command line :
python nufft.py                      (prints output on console)
or
python .\nufft.py                    (prints output on terminal)
or
python .\nufft.py > output.txt       (stores results in output.txt file)

NOTE:
1. The plots for results will be saved in .png format in the same folder.
2. The EEG signals dataset can be found in "non_uniform_input.csv" file.
3. Do not try to run "min_max_using_non_uniform_data.py" and "low_rank_using_non_uniform_data.py" file.


Output format:-------------------------------------------------------------------------------------------------------

min max interpolation result :
[........]

low rank approximation result :
[........]

ANOVA test results:
....

Root Mean Square Error:
....

