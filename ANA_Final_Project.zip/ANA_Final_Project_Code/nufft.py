import numpy as np
import pandas as pd
import warnings
from scipy.stats import f_oneway
import matplotlib.pyplot as plt
import low_rank_using_non_uniform_data as lowrank
import min_max_using_non_uniform_data as minmax
warnings.simplefilter("ignore")


def load_dataset():
    input_df = pd.read_csv("non_uniform_input.csv")
    input_df = input_df[~np.isnan(input_df)]
    x = np.array(input_df)[0:1000, 0]
    y = np.sin(x)

    return x, y


def perform_anova_test():
    # Perform ANOVA
    f_value, p_value = f_oneway(minmax_result, lowrank_result)
    # Print results
    print("ANOVA test results:")
    print("F-value:", f_value)
    print("p-value:", p_value)


def calculate_root_mean_square_error():
    rmse = np.sqrt(np.mean((minmax_result - gt_y) ** 2))
    print("\nRMSE between min-max interpolation and ground truth value:", rmse)
    rmse = np.sqrt(np.mean((lowrank_result - gt_y) ** 2))
    print("\nRMSE between low rank approximation and ground truth value:", rmse)


def plot_min_max_interpolation_results():
    # Plot the min max interpolation results
    plt.figure(1)
    magnitude = np.abs(minmax_result) * 1200
    magnitude[magnitude > 1600] = 0
    plt.plot(magnitude)
    plt.xlabel('Frequency')
    plt.ylabel('Amplitude')
    plt.title('FFT results: min max interpolation')
    plt.savefig("min_max.png")


def plot_low_rank_approximation_results():
    # Plot the low rank approximation results
    plt.figure(2)
    plt.plot(np.abs(lowrank_result))
    plt.xlabel('Frequency index')
    plt.ylabel('Amplitude')
    plt.title('FFT results: low rank approximation')
    plt.savefig("low_rank.png")


x, y = load_dataset()

gt_y = np.fft.fft(y)

N = 1000
M = 1000

omega = np.linspace(-np.pi, np.pi, N + 1)[:-1]  # Frequencies of interest
minmax_result, coeffs = minmax.nufft_min_max_interpolation(x, y, omega, len(x))
print("\n min max interpolation result : \n")
print(minmax_result)
print("\n")

lowrank_result = lowrank.nufft_low_rank_approximation(x, y, len(x))
print("\n low rank approximation result : \n")
print(lowrank_result)
print("\n")


perform_anova_test()

# compute magnitude of fourier transform results
minmax_result = np.abs(minmax_result)
lowrank_result = np.abs(lowrank_result)
gt_y = np.abs(gt_y)


calculate_root_mean_square_error()


plot_min_max_interpolation_results()


plot_low_rank_approximation_results()
