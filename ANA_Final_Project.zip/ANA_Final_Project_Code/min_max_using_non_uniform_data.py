import numpy as np
from scipy.linalg import dft


def nufft_min_max_interpolation(x, y, omega, M):
    # Compute the number of non-uniformly sampled points
    N = len(x)

    # Compute the FFT of the uniform grid
    uniform_fft = dft(M, scale='sqrtn')

    # Compute the FFT of the non-uniform grid
    nonuniform_fft = uniform_fft @ np.diag(np.exp(-2j * np.pi * x / M))

    # Compute the nonuniform-to-uniform interpolation matrix
    j = np.floor((M - 1) * (x - np.min(x)) / (np.max(x) - np.min(x)))
    delta = x - j * (np.max(x) - np.min(x)) / (M - 1)
    k = np.arange(-int(M / 2), int(M / 2))
    interpolation_matrix = np.exp(-2j * np.pi * delta * k / (np.max(x) - np.min(x))) / np.sqrt(M)

    # Compute the Fourier coefficients using min-max interpolation
    coeffs = interpolation_matrix @ y[j.astype(int)] * np.exp(-1j * omega * j / N)

    # Compute the NUFFT using the inverse FFT
    nufft = (nonuniform_fft.T @ coeffs)

    return nufft, coeffs
