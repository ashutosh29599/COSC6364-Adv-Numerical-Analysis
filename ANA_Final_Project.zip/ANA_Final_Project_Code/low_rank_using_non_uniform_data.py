import numpy as np


def nufft_low_rank_approximation(k, data, N):

    # Compute DFT of a uniformly spaced grid of length N
    uniform_grid = np.linspace(-np.pi, np.pi, N, endpoint=False)
    uniform_data = np.fft.fftshift(np.fft.fft(np.fft.ifftshift(data)))

    # Compute the Vandermonde matrix
    vandermonde_matrix = np.exp(1j * np.outer(k, uniform_grid))

    # Compute the low rank approximation using SVD
    U, s, Vh = np.linalg.svd(vandermonde_matrix, full_matrices=False)
    rank = np.count_nonzero(s >= np.finfo(float).eps * s[0])
    Vtilde = np.dot(U[:, :rank] * s[:rank], Vh[:rank, :])

    # Compute the NUFFT using the inverse FFT
    nufft = np.dot(np.conj(Vtilde.T), uniform_data)

    return nufft







